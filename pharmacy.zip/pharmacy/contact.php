<html>
<?php 
extract($_POST);
if(isset($save)) {

		$n = $_POST['n'];
		$m = $_POST['m'];
		$e = $_POST['e'];
		$msg = $_POST['msg'];

		$servername = "localhost";
		$username = "root";
		$password = "password";

		// Create connection
		$conn = new mysqli($servername, $username, $password);
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 

		// Create database
		$sql = "CREATE DATABASE IF NOT EXISTS pharmacydb";
		if ($conn->query($sql) === TRUE) {
			//echo "Database created successfully";
			$conn->close();
		}

		// Create table
		$table_sql = "CREATE TABLE contact (
				name varchar(255),
				email varchar(255),
				phno varchar(255),
				message varchar(500))";

		if ($conn->query($table_sql) === TRUE) {
			//echo "Table created successfully";
			mysqli_query($conn,"insert into contact values('$n','$e','$m','$msg')");	
			$conn->close();
		}
	}
?>

	<head>
		<style>
			#title{
				background-color:#000080;
				font-size:33px;
				
				
				color:white;
				margin-left:20px;
				margin-top:20px;
				margin-bottom:20px;
				
				}
				
			ul {
			list-style-type: none;
			margin: 50;
			padding: 0;
			overflow: hidden;
			background-color: #000080;
			}
			
			li {
				float: right;
			}
			
			#titlehead{
				float: left;
			}

			li a {
				display: block;
				color: white;
				font-size:20px;
				text-align: center;
				padding: 16px 20px;
				margin-top:10px;
				text-decoration: none;
			}

			li a:hover:not(.active) {
				background-color: #000000;
			}

			.active {
				background-color: #000000;
				
			}
			
			#home_img{
				padding-left:50px;
				padding-bottom:10px;
				
			}
			
			#bottom_posts{
				
				display: grid;
				grid-template-columns: auto auto auto;
				padding: 5px;
			
			}
			
			#img_title{
				
				display: grid;
				grid-template-columns: auto auto auto;
				padding: 5px;
			
			}
			
			#posts{
				padding: 20px;
				font-size: 30px;
				text-align: center;
			
			}
			
			/*input[type=text] {
			  width: 100%;
			  padding: 12px 20px;
			  margin: 8px 0;
			  box-sizing: border-box;
			}*/
			body {
			  background-image: url("image/bg4.jpg");
			  background-repeat: no-repeat;
			  background-position: center center;
				background-attachment: fixed;
				background-size: cover;
			}

		</style>
	</head>
	
	<body>		
		<ul>
			<li id="titlehead"><p id="title">SRI MARUTHI PHARMA</p></li>
			<li><a  href="about.php">About Us</a></li>
			<li><a class="active" href="contact.php">Contact Us</a></li>
			<li><a href="home.php">Home</a></li>
		</ul>
		
		<div id=bottom_posts>
			<div class="row">
            <div class="col-md-8">
                <h3><font color="#000000">Contact us </font></h3>
                <form name="sentMessage" method="post" id="contactForm" novalidate>
                  <?php echo @$err; ?>
				    <div class="control-group form-group">
						<div class="controls">
                            <label>Name:</label>
                            <input type="text" class="form-control" name="n" required data-validation-required-message="Please enter your name.">
                            <p class="help-block"></p>
                        </div>
                    </div>
                    <div class="control-group form-group">
                        <div class="controls">
                            <label>Mobile Number:</label>
                            <input type="number" class="form-control" name="m" required data-validation-required-message="Please enter your phone number.">
                        </div>
                    </div><br>
                    <div class="control-group form-group">
                        <div class="controls">
                            <label>Email Address:</label>
                            <input type="email" class="form-control" name="e" required data-validation-required-message="Please enter your email address.">
                        </div>
                    </div> <br>
                    <div class="control-group form-group">
                        <div class="controls">
                            <label>Message:</label>
                            <textarea rows="10" name="msg" cols="100" class="form-control" id="message" required data-validation-required-message="Please enter your message" maxlength="999" style="resize:none"></textarea>
                        </div>
                    </div><br>
                    <div id="success"></div>
                    <!-- For success/fail messages -->
                    <button type="submit" name="save" class="btn btn-primary">Send Message</button>
					<h1></h1>
                </form>
            </div>
			<div class="col-md-4" style="margin-top:30px">
                <h3>Contact Details</h3>
                <p>
                    Sri Maruthi Pharma<br>Bangalore<br>
                </p>
                <p><i class="fa fa-phone"></i> 
                    <abbr title="Phone">Phone number</abbr>:1234567890</p>
                <p><i class="fa fa-envelope-o"></i> 
                    <abbr title="Email">Email id</abbr>: <a href="mailto:maruthipharma@gmail.com">maruthipharma@gmail.com</a>
                </p>
                <p><i class="fa fa-clock-o"></i> 
                    <abbr title="Hours">Timings</abbr>: Monday - Sunday: 9:00 AM to 10:00 PM</p>
                <ul class="list-unstyled list-inline list-social-icons">
                    <li>
                        <a href=<img src="image\face.jfif" width=236 height=236 >
                            <i class="fa fa-facebook-square fa-2x"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-linkedin-square fa-2x"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-twitter-square fa-2x"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-google-plus-square fa-2x"></i></a>
                    </li>
                </ul>
            </div>
        </div>
		
	</body>
	
</html>