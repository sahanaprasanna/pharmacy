<html>
<?php
// Start the session
session_start();
?>
	<head>
		<style>
			#title{
				background-color:#000080;
				font-size:33px;
				
				
				color:white;
				margin-left:20px;
				margin-top:20px;
				margin-bottom:20px;
				
				}
				
			ul {
			list-style-type: none;
			margin: 50;
			padding: 0;
			overflow: hidden;
			background-color: #000080;
			}
			
			li {
				float: right;
			}
			
			#titlehead{
				float: left;
			}

			li a {
				display: block;
				color: white;
				font-size:20px;
				text-align: center;
				padding: 16px 20px;
				margin-top:10px;
				text-decoration: none;
			}

			li a:hover:not(.active) {
				background-color: #000000;
			}

			.active {
				background-color: #000000;
				
			}
			
			#home_img{
				padding-left:50px;
				padding-bottom:10px;
				
			}
			
			#bottom_posts{
				
				display: grid;
				grid-template-columns: auto auto auto;
				padding: 5px;
			
			}
			
			#img_title{
				
				display: grid;
				grid-template-columns: auto auto auto;
				padding: 5px;
			
			}
			
			#posts{
				padding: 20px;
				font-size: 30px;
				text-align: center;
			
			}
			
			body {
			  background-image: url("image/bg2.jfif");
			  background-repeat: no-repeat;
			  background-position: center center;
				background-attachment: fixed;
				background-size: cover;
			}

		</style>
	</head>
	
	<body>		
		<ul>
			<li id="titlehead"><p id="title">SRI MARUTHI PHARMA</p></li>
			<li><a class="active" href="about.php">About Us</a></li>
			<li><a href="contact.php">Contact Us</a></li>
			<li><a href="home.php">Home</a></li>
			
		</ul>
		
		<div id=bottom_posts>
		
			<div id=posts>
				<h2 style="font-size:50px;"> About Us</h2>
				<div id=img_title>
					<img src="image\logo.png" width=236 height=236 >
					<p style="font-size:40px;"> SMP is a company, established under a mission of service to humanity, we provide a
wide range of pharmaceuticals and we are building a reputation of quality and integrity known
around the world.
The products that we supply at SMP Meets the best safety and quality standards. We are being
audited regularly by officials to ensure that the highest safety and quality criteria were met.<br><br>
 </p>

				
				</div>
			
			</div>
		
		
		</div>
		
		
		
		
		<?php
		
		$servername = "localhost";
		$username = "root";
		$password = "";

		// Create connection
		$conn = new mysqli($servername, $username, $password);
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 

		// Create database
		$sql = "CREATE DATABASE IF NOT EXISTS pharmacydb";
		if ($conn->query($sql) === TRUE) {
			//echo "Database created successfully";
			
		
		
		$conn->close();
		}
		?>
		
	</body>
	
</html>