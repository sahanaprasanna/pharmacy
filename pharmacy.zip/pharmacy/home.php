<html>
<?php
// Start the session
session_start();
?>
	<head>
		<style>
			
  

			#title{
				background-color:#000080;
				font-size:33px;
				
				
				color:white;
				margin-left:20px;
				margin-top:20px;
				margin-bottom:20px;
				
				}
				
			ul {
			list-style-type: none;
			margin: 50;
			padding: 0;
			overflow: hidden;
			background-color: #000080;
			}
			
			li {
				float: right;
			}
			
			#titlehead{
				float: left;
			}

			li a {
				display: block;
				color: white;
				font-size:20px;
				text-align: center;
				padding: 16px 20px;
				margin-top:10px;
				text-decoration: none;
			}

			li a:hover:not(.active) {
				background-color: #000000;
			}

			.active {
				background-color: #000000;
				
			}
			
			#home_img{
				padding-left:50px;
				padding-bottom:10px;
				
			}
			
			#bottom_posts{
				
				display: grid;
				grid-template-columns: auto auto auto;
				padding: 5px;
			
			}
			
			#img_title{
				
				display: grid;
				grid-template-columns: auto auto auto;
				padding: 5px;
			
			}
			
			#posts{
				padding: 20px;
				font-size: 30px;
				text-align: center;
			
			}
			body {
			  background-image: url("image/bg5.jpg");
			  background-repeat: no-repeat;
			  background-position: center center;
				background-attachment: fixed;
				background-size: cover;
			}
			
		</style>
	</head>
	
	<body>
		
		
		
		<ul>
			<li id="titlehead"><p id="title">SRI MARUTHI PHARMA</p></li>
			<li><a href="about.php">About Us</a></li>
			<li><a href="contact.php">Contact Us</a></li>
			<li><a class="active" href="home.php">Home</a></li>
			
		</ul>
		
		<div id=bottom_posts>
		
			<div id=posts>
				<h2 style="font-size:40px;"> Overview: </h2>
				<div id=img_title>
					<img src="image\logo.png" width=236 height=236 >
					<p style="font-size:30px;"> Sri Maruthi Pharma in Bangalore is one of the leading businesses in Surgical Equipment Dealers. Also known for Surgical Equipment Dealers, Pharmaceutical Product Distributors, Medical Equipment Dealers, Pharmaceutical Distributors, Surgical Item Dealers, Medicine Distributors, Medical Product Dealers, Generic
Medicine Wholesalers and much more.<br><br>

We are dealers in: <br><br>

Chemists
<br>Surgical Equipment Dealers
<br>Pharmaceutical Product Distributors
<br>Medical Equipment Dealers
<br>Pharmaceutical Distributors
<br>Pharmaceutical Product Manufacturers
<br>Medicine Wholesalers
<br>Surgical Face Mask Dealers
<br>N95 Face Mask Dealers
<br>Medicine Distributors
<br>Generic Medicine Distributors
<br>Pharmaceutical Product Wholesalers and much more </p>

				
				</div>
			
			</div>
		
		
		</div>
		
		
		
		
		<?php
		
		$servername = "localhost";
		$username = "root";
		$password = "";

		// Create connection
		$conn = new mysqli($servername, $username, $password);
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 

		// Create database
		$sql = "CREATE DATABASE IF NOT EXISTS pharmacydb";
		if ($conn->query($sql) === TRUE) {
			//echo "Database created successfully";
			
		
		
		$conn->close();
		}
		?>
		
	</body>
	
</html>